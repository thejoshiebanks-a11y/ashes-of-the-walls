// The creator opening (js/story/strike.js) and the upright animation set. Run: node tests/strike.test.js
const assert = require('assert'), fs = require('fs'), path = require('path'); globalThis.STORY = {};
const K = require('../js/story/strike.js'), R = path.resolve(__dirname, '..'); let n = 0;
const t = (name, f) => { try { f(); n++; console.log('ok   ' + name); } catch (e) { console.error('FAIL ' + name + '\n     ' + e.message); process.exitCode = 1; } };
const ctx = () => new Proxy({}, { get: (o, k) => k in o ? o[k] : (k === 'createLinearGradient' || k === 'createRadialGradient' ? () => ({ addColorStop() { } }) : () => { }), set: (o, k, v) => { o[k] = v; return true; } });
function run(skipAt) {
  const a = { key: 'boy', baseScale: .65 / 1.9486, x: 0, z: 0, hidden: false, tintFn: null }, ev = [], log = { fly: [], clips: [] };
  const st = K.create({ actor: () => a, stage: { x: 10, z: 20, gy: 1, yaw: .1 }, audio: { thunder: (l, c) => ev.push('thunder' + (c ? 'C' : '')), blade: () => ev.push('blade'), boom: () => ev.push('boom') }, bodyHeight: () => 1.9486, showUI: () => ev.push('ui'), done: (h, s) => ev.push(s ? 'skipped' : 'done') });
  assert(a.hidden, 'the character is hidden until the strike'); const c2 = ctx(); let hid0 = a.hidden;
  for (let tt = 0; tt < 18; tt += 1 / 60) { const c = st.update(1 / 60); if (c) for (const v of [...c.pos, ...c.target, c.fov]) assert(Number.isFinite(v), 'camera finite at ' + tt); st.draw(c2, 667, 375); log.fly.push(a.fly || 0); if (a.forceClip && log.clips[log.clips.length - 1] !== a.forceClip[0]) log.clips.push(a.forceClip[0]); if (skipAt && tt > skipAt) { st.skip(); break; } }
  return { a, ev, st, log };
}
t('the strike plays once, in order: thunder, fall, landing, rise, walk, idle, then hands over', () => { const { a, ev, st, log } = run(); assert(!st.active); /* order checked below */
  assert.deepStrictEqual(log.clips.slice(0, 5), ['M:Jumping Down', 'M:Crouch To Stand', 'M:Idle', 'M:Walking', 'M:Idle']); assert(ev.includes('thunderC') && ev.includes('blade') && ev.includes('ui') && ev.includes('done')); assert(ev.indexOf('ui') < ev.indexOf('done'));
  assert(Math.max(...log.fly) > 1 && log.fly[log.fly.length - 1] === 0, 'falls from above and ends on the ground'); assert.strictEqual(a.forceClip, null); assert(!a.hidden && a.fly === 0 && a.clipT == null); });
t('skipping lands the character on the stage, visible, un-tinted, and hands over', () => { const { a, ev, st } = run(3); assert(!st.active); assert(ev.includes('skipped')); assert(!a.hidden && a.x === 10 && a.z === 20 && a.tintFn === null && !a.forceClip); const h = st.handoff; assert(h && h.fov > .2 && h.fov < .3); });
t('the animation set is baked into the game: upright idle, walk, run, jump, landing, rise, turn, talk', () => {
  const m = JSON.parse(fs.readFileSync(R + '/data/models.json', 'utf8')).anims.meta.clips; for (const k of ['Idle', 'Breathing Idle', 'Walking', 'Running', 'Jump', 'Jumping Down', 'Crouch To Stand', 'Right Turn', 'Talking', 'Telling A Secret']) assert(m['M:' + k] && m['M:' + k].n > 10, k);
  assert(m['M:Jumping Down'].n === 76 && m['M:Crouch To Stand'].n === 101); });
t('everyday life of every creator character uses the upright clips', () => { const src = fs.readFileSync(R + '/js/story/teen.js', 'utf8'); assert(/M:Idle/.test(src) && /M:Walking/.test(src) && /M:Running/.test(src)); assert(/forceClip/.test(fs.readFileSync(R + '/js/game.js', 'utf8'))); });
t('the camera starts very wide, tracks the fall down, and ends on the studio close-up', () => { const k0 = K.kf(0), kf = K.kf(K.TM.end); assert(k0.dist >= 28 && k0.fov > .85, 'wide establishing shot'); assert(Math.abs(kf.dist - 2.3) < .05 && Math.abs(kf.fov - .24) < .01 && Math.abs(kf.h - 1.5) < .05, 'ends on the close-up the creator opens on');
  for (let x = 0; x < 16.6; x += .1) { const k = K.kf(x); for (const v of Object.values(k)) assert(Number.isFinite(v)); assert(k.dist > 2 && k.fov > .2 && k.fov < 1.0, 'sane at ' + x); } });
t('the storm lights the 3D scene (engine hook) and clears afterwards', () => { const g = fs.readFileSync(R + '/js/game.js', 'utf8'); assert(/window\.__storm/.test(g)); const { st } = run(); assert(!globalThis.__storm, 'storm released'); });
t('the bolt follows the faller and ground impact has debris, rings and fog', () => { const a = { key: 'boy', baseScale: .33, x: 0, z: 0, hidden: false, tintFn: null }; const calls = {}; const c = new Proxy({}, { get: (o, k) => k === 'createLinearGradient' || k === 'createRadialGradient' ? () => ({ addColorStop() { } }) : (...x) => { calls[k] = (calls[k] || 0) + 1; }, set: () => true });
  const st = K.create({ actor: () => a, stage: { x: 0, z: 0, gy: 0, yaw: 0 }, audio: {}, bodyHeight: () => 1.9486, showUI() { }, done() { } }); for (let i = 0; i < 60 * 8; i++) { st.update(1 / 60); st.draw(c, 667, 375); } assert(calls.stroke > 200 && calls.ellipse !== 0 && calls.fillRect > 100); });
t('the creator character keeps a living neck, head and hair (engine layer)', () => { const g = fs.readFileSync(R + '/js/game.js', 'utf8'); assert(/function liveHead/.test(g) && /function liveHair/.test(g) && /M\.adj=a\.live/.test(g) && /uniform vec4 hsw/.test(g)); assert(/a\.live = true/.test(fs.readFileSync(R + '/js/story/teen.js', 'utf8'))); });
console.log(n + ' checks passed');
