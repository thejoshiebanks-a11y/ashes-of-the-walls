# Character creator pack (v0.6.0)

Only the character-creator files. It will NOT overwrite your opening/title work except where it must change a shared file, and those are delivered as patches (not whole files) so your own edits survive.

## Contents
- NEW files (safe to copy, they do not exist in your repo): `js/story/creator.js`, `js/story/studio.js`, `assets/ui/` (Paths backdrop + 35 thumbnails), `assets/kit/` (character models), `tools/kit/`, `tools/thumbs/`, `tests/creator|morph|studio.test.js`
- `patches/` : changes to SHARED files (game.js, actors.js, ui.js, main.js, story.css, boot.js, config.json and 3 tests). Made against the previous version of each file; apply with 3-way merge so your edits stay.
- Character models must be added into YOUR `assets/npc.pack` + `data/npc_models.json` by `tools/kit/add_to_npc_pack.py` (step 4). `ready-made-data/` is a fallback that replaces both files (only use it if you have not changed them).

## Codespace commands
```
cd /workspaces/<your-repo>            # repo root, where index.html is
git add -A && git commit -m "before creator pack"     # safety point
unzip -o /path/to/creator-pack.zip     # after uploading the zip to the Codespace (drag it into the file explorer)
bash creator-pack/apply.sh
python3 -m http.server 8765            # then open the forwarded port, or push to GitHub Pages
rm -rf creator-pack                    # when done
```
Undo everything: `git reset --hard && git clean -fd`
