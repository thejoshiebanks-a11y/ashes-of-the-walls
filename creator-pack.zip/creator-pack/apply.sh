#!/usr/bin/env bash
# Run from the ROOT of your repo (where index.html is):  bash creator-pack/apply.sh
set -e
P="$(cd "$(dirname "$0")" && pwd)"
[ -f index.html ] || { echo "Run this from your repo root (where index.html is)"; exit 1; }
echo "1/4 copying new files"; cp -r "$P/js" "$P/assets" "$P/tools" "$P/tests" .
echo "2/4 patching shared files (3-way merge, your edits stay)"
for f in "$P"/patches/*.patch; do
  if git apply --3way --whitespace=nowarn "$f" 2>/dev/null; then echo "  ok   $(basename "$f")";
  elif patch -p1 -N --no-backup-if-mismatch < "$f" >/dev/null 2>&1; then echo "  ok   $(basename "$f") (patch)";
  else echo "  CONFLICT $(basename "$f")  -> send me this file, I will merge it"; fi
done
echo "3/4 adding character models to your npc.pack"
for k in base_furlan base_isabel base_tomako base_loud base_anime; do python3 tools/kit/add_to_npc_pack.py $k rigbase; done
for k in head_furlan head_isabel head_tomako head_loud head_anime head_akane head_medieval head_benimaru; do python3 tools/kit/add_to_npc_pack.py $k righead; done
python3 tools/kit/add_to_npc_pack.py mannequin mannequin
echo "4/4 running tests"; for t in creator morph studio story_logic story_smoke actor_pose; do node tests/$t.test.js | tail -1; done
echo "done"
